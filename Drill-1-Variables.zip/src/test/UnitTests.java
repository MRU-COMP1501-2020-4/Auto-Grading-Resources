package test;

import main.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UnitTests {

	@Test
	void testBoolean() {
		assertTrue(Main.gimmeABoolean(false));
		assertFalse(Main.gimmeABoolean(true));
	}
	
	@Test
	void testInt() {
		assertEquals(10, Main.gimmeAnInt(100));
		assertEquals(2, Main.gimmeAnInt(22));
		assertEquals(0, Main.gimmeAnInt(2));
	}
	
	@Test 
	void testChar() {
		assertEquals(' ', Main.gimmeAChar('x'));
		assertEquals(' ', Main.gimmeAChar('A'));
		assertEquals('A', Main.gimmeAChar('a'));
	}

	@Test
	void testDouble() {
		assertEquals(10.0, Main.gimmeADouble(100), 0.0001);
		assertEquals(2.2, Main.gimmeADouble(22), 0.0001);
		assertEquals(0, Main.gimmeADouble(0), 0.0001);
	}
	
}
