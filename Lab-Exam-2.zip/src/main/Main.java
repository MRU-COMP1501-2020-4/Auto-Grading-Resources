package main;

import java.util.Random;

public class Main {

  public static void main(String[] args) {

    AverageBot bot = new AverageBot();
    Random r = new Random();

    System.out.printf(
        "AverageBot starting off. Average %.2f, total %.2f, number of numbers %d%n",
        bot.getAverage(), bot.getTotal(), bot.getNumberOfNumbers());
    bot.addNumber(10.1);
    System.out.printf(
        "AverageBot after adding a number. Average %.2f, total %.2f, number of numbers %d%n",
        bot.getAverage(), bot.getTotal(), bot.getNumberOfNumbers());
    bot.addNumber(10.1);
    System.out.printf(
        "AverageBot after adding 2 numbers. Average %.2f, total %.2f, number of numbers %d%n",
        bot.getAverage(), bot.getTotal(), bot.getNumberOfNumbers());
    for (int i = 0; i < 5; i++) {
      double number = r.nextDouble() * 10;
      System.out.printf("Adding %.2f%n", number);
      bot.addNumber(number);
    }
    System.out.printf(
        "AverageBot after adding 7 numbers. Average %.2f, total %.2f, number of numbers %d%n",
        bot.getAverage(), bot.getTotal(), bot.getNumberOfNumbers());
  }
}
