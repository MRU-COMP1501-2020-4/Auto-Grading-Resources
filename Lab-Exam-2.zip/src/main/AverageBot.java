package main;

/**
 * AverageBot, much less exciting than SassyBot, keeps track of the average value of a bunch of
 * doubles.
 *
 * <p>It does this by keeping a total of the doubles it's seen (in the addNumber() method) and the
 * number of numbers its seen. It then calculates the average by dividing the total by the number of
 * numbers.
 */
public class AverageBot {

  /** The total of all the numbers added to the bot. */
  private double total;
  /** The number of numbers added to the bot. */
  private int numberOfNumbers;

  /** Creates a new AverageBot, with the total and number of numbers set to 0. */
  public AverageBot() {}

  /**
   * Adds a new number to the bot. The number is added it to the total and counting one more number
   * of numbers
   */
  public void addNumber(double number) {}

  /**
   * Calculates and returns the average of all the numbers added to the bot.
   *
   * <p>Calculated by dividing the total by the number of numbers.
   *
   * @return the average of all numbers added to the bot.
   */
  public double getAverage() {}

  /**
   * Returns the number of numbers the bot has seen (how many times addNumber()) has been called).
   *
   * @return the number of numbers the bot has seen
   */
  public int getNumberOfNumbers() {}

  /**
   * Returns the sum of all numbers the bot has seen.
   *
   * @return the total of all numbers the bot has seen.
   */
  public double getTotal() {}
}
