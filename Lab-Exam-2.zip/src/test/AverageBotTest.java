package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import main.AverageBot;

class AverageBotTest {

  @Test
  void testNewAverageBot() {
    AverageBot c = new AverageBot();
    assertEquals(0, c.getNumberOfNumbers(), "A new AverageBot should start with 0 numberOfNumbers");
    assertEquals(0, c.getTotal(), 0.0001, "A new AverageBot should start with 0 total");
    assertEquals(Double.NaN, c.getAverage(), 0.0001, "A new AverageBot should start with 0 total");
  }

  @Test
  void testAddNumber() {
    AverageBot c = new AverageBot();
    c.addNumber(1.1);
    assertEquals(
        1, c.getNumberOfNumbers(), "After adding a number there should be 1 numberOfNumbers");
    assertEquals(1.1, c.getTotal(), 0.0001, "After adding just 1.1 then the total should  be 1.1");
    assertEquals(
        1.1, c.getAverage(), 0.0001, "After adding just 1.1 then the average should be 1.1");
    c.addNumber(1.1);
    assertEquals(
        2, c.getNumberOfNumbers(), "After adding 2 numbers there should be 2 numberOfNumbers");
    assertEquals(
        2.2, c.getTotal(), 0.0001, "After adding just 1.1 twice then the total should  be 2.2");
    assertEquals(
        1.1, c.getAverage(), 0.0001, "After adding 1.1 twice the average should still be 1.1");
    c.addNumber(1.1);
    assertEquals(
        3, c.getNumberOfNumbers(), "After adding 3 number there should be 3 numberOfNumbers");
    assertEquals(
        3.3,
        c.getTotal(),
        0.0001,
        "After adding just 1.1 three times then the total should  be 3.3");
    assertEquals(
        1.1, c.getAverage(), 0.0001, "After adding 1.1 twice the average should still be 1.1");
  }
}
