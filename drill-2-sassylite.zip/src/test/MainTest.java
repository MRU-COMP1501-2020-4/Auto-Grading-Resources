package test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Main;

class MainTest {



	@DisplayName("inital barb is correct")
	@Test
	public void inital_barb_is_whats_given_in_constructor() {

		assertThat(Main.initialBarb()).isEqualTo("SaSsY ChAt BoT SaYs PbBbBtH");
	}

	@DisplayName("lowercased chat text is all-capped")
	@Test
	public void lowercased_chat_text_is_all_capped() {
		String chatText = "say what?!?";
		String expectedSassiness = "your lips were saying \"SAY WHAT?!?\", but all I heard was \"blah, blah, blah\"";

		assertThat(Main.blahBlahRiposteTo(chatText)).isEqualTo(expectedSassiness);
	}

	@DisplayName("mixed-case chat text is all-capped")
	@Test
	public void mixcased_chat_text_is_all_capped() {
		String chatText = "But I thought we were friends, Sassy.";
		String expectedSassiness = "your lips were saying \"BUT I THOUGHT WE WERE FRIENDS, SASSY.\", but all I heard was \"blah, blah, blah\"";

		assertThat(Main.blahBlahRiposteTo(chatText)).isEqualTo(expectedSassiness);
	}

	@DisplayName("lowercase first letter in chat text")
	@Test
	public void lowercase_first_letter_in_chat_text() {
		String chatText = "whatcha doing on Sunday?";
		String expectedSassiness = "only dweebs start a sentence with the letter 'w'";

		assertThat(Main.onlyDweebsRiposteTo(chatText)).isEqualTo(expectedSassiness);
	}

	@DisplayName("uppercase first letter in chat text")
	@Test
	public void uppercase_first_letter_in_chat_text() {
		String chatText = "Sassy - you just TOO sassy!";
		String expectedSassiness = "only dweebs start a sentence with the letter 's'";

		assertThat(Main.onlyDweebsRiposteTo(chatText)).isEqualTo(expectedSassiness);
	}

}
