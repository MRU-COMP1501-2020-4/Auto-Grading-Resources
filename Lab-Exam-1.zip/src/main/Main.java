package main;

public class Main {

	public static void main(String[] args) {

		System.out.println(reportOnString("Hi"));
		System.out.println(reportOnString("Hello World"));
		System.out.println(reportOnString("Practice makes perfect"));
	}

	/**
	 * Tests whether the given number is even or not.
	 *
	 * Remember that a number is even if it is evenly divisible by 2, so we can
	 * evaluate that by finding the remainder of dividing the number by 2, and if
	 * the remainder is 0 then the number must be even.
	 * 
	 * Remember also that the he modulus operator (%) gives us the remainder
	 * 
	 *
	 * @param number the number to test
	 * @return true if number is even and false if number is odd
	 */
	public static boolean isEven(int number) {
	}

	/**
	 * 
	 * Returns a report on a string including the number of characters and whether
	 * the number of characters is even or odd.
	 * 
	 * The form for the report should be "The string "<the string>" is <number of
	 * chars> character long which is an <even or odd> number of characters.
	 * 
	 * This method relies on asking the string how long it is and using evenOrOdd to
	 * fill in the that part of the sting.
	 * 
	 * @param test the string to test.
	 * @return the formatted report on the test string.
	 */
	public static String reportOnString(String test) {
	}

	/**
	 * 
	 * Returns either the string "even" or "odd" if the number is even or odd.
	 * 
	 * This method relies on using the isEven() to determine if the number is even
	 * or odd.
	 * 
	 * @param number the number to look at
	 * @return the string "even" if number is even and "odd" if the number is odd.
	 */
	public static String evenOrOdd(int number) {
	}
}
