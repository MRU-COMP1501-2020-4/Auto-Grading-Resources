package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import main.Main;

class MainTest extends Main {

  @Test
  void testIsEven() {
    assertTrue(isEven(0), "0 is even so the result should be true");
    assertFalse(isEven(1), "1 is odd so the result should be false");
    assertFalse(isEven(17), "17 is odd so the result should be false");
    assertTrue(isEven(198), "198 is odd so the result should be true");
  }

  @Test
  void testEvenOrOdd() {
    assertEquals("even", evenOrOdd(0), "0 is even so the result should be \"even\"");
    assertEquals("even", evenOrOdd(2), "2 is even so the result should be \"even\"");
    assertEquals("odd", evenOrOdd(-1), "-1 is odd so the result should be \"odd\"");
    assertEquals("odd", evenOrOdd(1001), "1001 is odd so the result should be \"odd\"");
  }

  @Test
  void testReportOnString() {
    assertEquals(
        "The string \"Hi\" is 2 characters long which is an even number of characters.",
        reportOnString("Hi"));
    assertEquals(
        "The string \"bob\" is 3 characters long which is an odd number of characters.",
        reportOnString("bob"));
    assertEquals(
        "The string \"supercalifragilisticexpialidocious\" is 34 characters long which is an even number of characters.",
        reportOnString("supercalifragilisticexpialidocious"));
    assertEquals(
        "The string \"    \" is 4 characters long which is an even number of characters.",
        reportOnString("    "));
  }
}
