package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.Counter;

class CounterTest {

  @Test
  void testNewCounter() {
    Counter c = new Counter();
    assertEquals(0, c.getCount(), "A new counter should start with a count of 0");
  }

  @Test
  void testCount() {
    Counter c = new Counter();
    c.count();
    assertEquals(1, c.getCount(), "After 1 call to .count() the count should be 1");
    c.count();
    assertEquals(2, c.getCount(), "After 2 calls to .count() the count should be 2");
    c.count();
    assertEquals(3, c.getCount(), "After 3 calls to .count() the count should be 3");
  }

  @Test
  void testReset() {
    Counter c = new Counter();
    c.count();
    c.count();
    c.count();
    c.reset();
    assertEquals(0, c.getCount(), "After call to .reset() the count should be 0");
  }
}
